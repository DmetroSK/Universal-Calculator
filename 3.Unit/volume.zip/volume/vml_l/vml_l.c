#include<stdio.h>
int main()
{float l,ml;
    printf("Enter the volume in milliliter : ");
    scanf("%f",&ml);
    l = ml/1000;
    printf("%.2f ml = %.3f l",ml,l);
}

