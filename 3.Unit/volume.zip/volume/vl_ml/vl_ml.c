#include<stdio.h>
int main()
{float l,ml;
    printf("Enter the volume in Liter : ");
    scanf("%f",&l);
    ml = l*1000;
    printf("%.2f l = %.2f ml",l,ml);
}
