#include<stdio.h>
int main()
{float m, mm;
    printf("Enter the distance in meters : ");
    scanf("%f",&m);
         mm = m *1000;
    printf("%.2f m = %.2f mm\n\n",m,mm);

return 0;
}
