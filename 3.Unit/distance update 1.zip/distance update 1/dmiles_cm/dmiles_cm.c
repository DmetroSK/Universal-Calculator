#include<stdio.h>
int main()
{float m, cm;
    printf("Enter the distance in miles : ");
    scanf("%f",&m);

         cm = m * 160934;
    printf("%f miles = %.2f cm\n\n",m,cm);

return 0;
}

