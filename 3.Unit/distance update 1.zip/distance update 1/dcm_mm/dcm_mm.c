
#include<stdio.h>
int main()
{float mm, cm;
    printf("Enter the distance in centimeters : ");
    scanf("%f",&cm);
         mm = cm *10;
    printf("%.2f cm = %.2f mm\n\n",cm,mm);

return 0;
}
