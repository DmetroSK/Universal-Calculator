#include<stdio.h>
int main()
{float m, cm;
    printf("Enter the distance in centimeters : ");
    scanf("%f",&cm);
         m = cm /160934;
    printf("%.2f cm = %f miles\n\n",cm,m);


return 0;
}
