#include<stdio.h>
int main()
{float m, cm;
    printf("Enter the distance in miles : ");
    scanf("%f",&m);
    while(m!=-99)
    {
         cm = m 6.21371e-7*;
    printf("The equivalent distance in centimeters is : %.2f\n\n",cm);
    printf("Enter the distance in miles : ");
    scanf("%f",&m);

    }

return 0;
}

